import User from "./userModel";

export{User};